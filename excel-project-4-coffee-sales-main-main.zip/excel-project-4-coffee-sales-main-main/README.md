# excel-project-4-coffee-sales-main
"Excel Project 4: Coffee Sales Analysis. Explore sales trends, customer preferences, and revenue drivers using Excel for actionable business insights."
